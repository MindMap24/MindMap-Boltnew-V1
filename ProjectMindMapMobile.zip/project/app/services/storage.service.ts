import { ApplicationSettings } from '@nativescript/core';

export class StorageService {
    private static instance: StorageService;

    private constructor() {}

    static getInstance(): StorageService {
        if (!StorageService.instance) {
            StorageService.instance = new StorageService();
        }
        return StorageService.instance;
    }

    saveUser(user: { username: string; password: string }): void {
        ApplicationSettings.setString('user', JSON.stringify(user));
    }

    getUser(): { username: string; password: string } | null {
        const userData = ApplicationSettings.getString('user');
        return userData ? JSON.parse(userData) : null;
    }

    saveJournalEntries(entries: any[]): void {
        ApplicationSettings.setString('journal', JSON.stringify(entries));
    }

    getJournalEntries(): any[] {
        const entries = ApplicationSettings.getString('journal');
        return entries ? JSON.parse(entries) : [];
    }

    saveMoodEntries(moods: any[]): void {
        ApplicationSettings.setString('moods', JSON.stringify(moods));
    }

    getMoodEntries(): any[] {
        const moods = ApplicationSettings.getString('moods');
        return moods ? JSON.parse(moods) : [];
    }
}