import { GoogleGenerativeAI } from '@google/generative-ai';

export class AIService {
    private genAI: GoogleGenerativeAI;
    private model: any;

    constructor() {
        this.genAI = new GoogleGenerativeAI('AIzaSyDVJQ9VHPNLANEoh-G17YtvqbtntKY-GGg');
        this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });
    }

    async chat(message: string): Promise<string> {
        try {
            const result = await this.model.generateContent(message);
            const response = await result.response;
            return response.text();
        } catch (error) {
            console.error('AI Chat Error:', error);
            return 'Sorry, I encountered an error. Please try again.';
        }
    }
}