export interface User {
    username: string;
    password: string;
}

export interface JournalEntry {
    id: string;
    date: Date;
    content: string;
    mood: string;
}

export interface MoodEntry {
    date: Date;
    mood: 'positive' | 'negative';
    description: string;
}