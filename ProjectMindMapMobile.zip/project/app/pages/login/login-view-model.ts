import { Observable } from '@nativescript/core';
import { StorageService } from '../../services/storage.service';

export class LoginViewModel extends Observable {
    private storage = StorageService.getInstance();
    username: string = '';
    password: string = '';

    constructor() {
        super();
    }

    onLogin() {
        const user = this.storage.getUser();
        if (user && user.username === this.username && user.password === this.password) {
            // Navigate to main page
            const frame = require('@nativescript/core').Frame;
            frame.topmost().navigate({
                moduleName: 'pages/main/main-page',
                clearHistory: true
            });
        } else {
            alert('Invalid credentials');
        }
    }

    onNavigateToSignup() {
        const frame = require('@nativescript/core').Frame;
        frame.topmost().navigate('pages/signup/signup-page');
    }
}