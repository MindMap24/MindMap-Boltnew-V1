import { Observable } from '@nativescript/core';
import { StorageService } from '../../services/storage.service';

export class SignupViewModel extends Observable {
    private storage = StorageService.getInstance();
    username: string = '';
    password: string = '';
    confirmPassword: string = '';

    constructor() {
        super();
    }

    onSignup() {
        if (this.password !== this.confirmPassword) {
            alert('Passwords do not match');
            return;
        }

        this.storage.saveUser({
            username: this.username,
            password: this.password
        });

        const frame = require('@nativescript/core').Frame;
        frame.topmost().navigate({
            moduleName: 'pages/login/login-page',
            clearHistory: true
        });
    }

    onNavigateToLogin() {
        const frame = require('@nativescript/core').Frame;
        frame.topmost().navigate('pages/login/login-page');
    }
}