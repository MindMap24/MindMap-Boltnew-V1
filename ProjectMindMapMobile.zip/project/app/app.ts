import { Application } from '@nativescript/core';
import { AIService } from './services/ai.service';

// Initialize AI service globally
global.aiService = new AIService();

Application.run({ moduleName: 'pages/login/login-page' });